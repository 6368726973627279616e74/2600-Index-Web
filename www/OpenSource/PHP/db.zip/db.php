<?php
/*
  db.php

  Author:      wrepp
  Date:        10/13/2008
  Description: db info for 2600 index web site.
  Notes:       include file - no html.
*/
  $dbhost = 'localhost';
  $dbuser = '*your user here*';
  $dbpass = '*your password here*';
  $dbname = '2600';
?>
