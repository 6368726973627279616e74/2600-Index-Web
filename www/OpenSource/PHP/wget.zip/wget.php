<!--
  wget.php
-->

<?php
echo "ok";
?>

